"""
sql_agent.py — Load any DataFrame into an in-memory DuckDB database and run
SQL queries. Includes a helper that translates plain-English requests into SQL
using pattern matching, and always explains the resulting query.
"""
import duckdb
import pandas as pd
import re
from typing import Tuple, Optional, Dict


def df_to_sql(df: pd.DataFrame, table_name: str = "dataset") -> Tuple[duckdb.DuckDBPyConnection, str]:
    """Register a DataFrame as a SQL table inside a DuckDB in-memory database."""
    con = duckdb.connect(database=":memory:")
    con.register(table_name, df)
    nrows, ncols = df.shape
    explanation = (
        f"🗄️ Loaded your data into an in-memory SQL table called **{table_name}**.\n"
        f"   • {nrows:,} rows × {ncols:,} columns are now queryable with SQL.\n"
        "   • DuckDB supports advanced SQL: window functions, CTEs, joins, "
        "subqueries, date functions, and aggregation.\n"
        "   • Try: `SELECT * FROM dataset LIMIT 10;`"
    )
    return con, explanation


def run_sql(con: duckdb.DuckDBPyConnection, query: str) -> Tuple[pd.DataFrame, str]:
    """Execute a SQL query and explain what it did."""
    try:
        result = con.execute(query).fetchdf()
        # Build explanation
        ql = query.strip().lower()
        if ql.startswith("select"):
            kind = "SELECT (read-only query)"
        elif ql.startswith(("create", "with")):
            kind = "CREATE / CTE"
        elif ql.startswith("insert"):
            kind = "INSERT"
        elif ql.startswith("update"):
            kind = "UPDATE"
        elif ql.startswith("delete"):
            kind = "DELETE"
        else:
            kind = "SQL"

        explanation = (
            f"✅ Ran {kind} successfully.\n"
            f"   • Returned {len(result):,} row(s) × {result.shape[1]} column(s).\n"
            f"   • Columns returned: {', '.join(map(str, result.columns))}"
        )
        return result, explanation
    except Exception as e:
        return pd.DataFrame(), f"❌ SQL error: {e}"


def get_schema(con: duckdb.DuckDBPyConnection, table: str = "dataset") -> Tuple[pd.DataFrame, str]:
    """Describe the schema of the table."""
    schema = con.execute(f"DESCRIBE {table}").fetchdf()
    explanation = (
        "📋 **Table schema:**\n"
        + "\n".join(
            f"   • {row['column_name']} — {row['column_type']}"
            for _, row in schema.iterrows()
        )
    )
    return schema, explanation


def explain_query(query: str) -> str:
    """Explain a SQL query in plain English, line by line."""
    lines = []
    q = query.strip().rstrip(";")

    # Detect common patterns
    upper = q.upper()
    lines.append("🧠 **Plain-English explanation of your query:**")

    if upper.startswith("WITH"):
        lines.append("   1. You're using a CTE (Common Table Expression) — a temporary result set that the main query can reference.")

    select_match = re.search(r"SELECT\s+(.*?)\s+FROM", q, re.IGNORECASE | re.DOTALL)
    if select_match:
        cols = select_match.group(1).strip()
        if cols == "*":
            lines.append("   2. SELECT * — you're returning every column.")
        else:
            lines.append(f"   2. SELECT these columns/expressions: {cols[:200]}.")

    from_match = re.search(r"FROM\s+(\w+)", q, re.IGNORECASE)
    if from_match:
        lines.append(f"   3. FROM the table `{from_match.group(1)}`.")

    joins = re.findall(r"(LEFT|RIGHT|INNER|FULL|CROSS)?\s*JOIN\s+(\w+)", q, re.IGNORECASE)
    if joins:
        for jtype, jtable in joins:
            jtype = (jtype or "INNER").upper()
            lines.append(f"   • {jtype} JOIN with `{jtable}`.")
        on_match = re.search(r"ON\s+(.+?)(?:WHERE|GROUP|ORDER|LIMIT|$)", q, re.IGNORECASE | re.DOTALL)
        if on_match:
            lines.append(f"     Matching rows where {on_match.group(1).strip()[:150]}.")

    where_match = re.search(r"WHERE\s+(.+?)(?:GROUP BY|ORDER BY|LIMIT|HAVING|$)", q, re.IGNORECASE | re.DOTALL)
    if where_match:
        lines.append(f"   4. Filtering rows WHERE {where_match.group(1).strip()[:200]}.")

    group_match = re.search(r"GROUP BY\s+(.+?)(?:ORDER BY|LIMIT|HAVING|$)", q, re.IGNORECASE | re.DOTALL)
    if group_match:
        lines.append(f"   5. Grouping (aggregating) by {group_match.group(1).strip()[:150]}.")

    order_match = re.search(r"ORDER BY\s+(.+?)(?:LIMIT|$)", q, re.IGNORECASE | re.DOTALL)
    if order_match:
        lines.append(f"   6. Sorting results by {order_match.group(1).strip()[:150]}.")

    limit_match = re.search(r"LIMIT\s+(\d+)", q, re.IGNORECASE)
    if limit_match:
        lines.append(f"   7. Limiting output to {limit_match.group(1)} rows.")

    if re.search(r"OVER\s*\(", q, re.IGNORECASE):
        lines.append("   • ⭐ You're using a WINDOW function (OVER clause) — this computes values across a set of table rows related to the current row (e.g. running totals, rankings, moving averages).")

    if re.search(r"ROW_NUMBER|RANK|DENSE_RANK", q, re.IGNORECASE):
        lines.append("   • ⭐ RANK/ROW_NUMBER detected — used for top-N-per-group analysis.")

    if re.search(r"CASE\s+WHEN", q, re.IGNORECASE):
        lines.append("   • ⭐ CASE WHEN detected — conditional logic (like IF/ELSE in SQL).")

    return "\n".join(lines)


def natural_language_to_sql(request: str, table: str = "dataset",
                            df: Optional[pd.DataFrame] = None) -> str:
    """
    Very lightweight natural-language → SQL translator.
    Handles common analyst requests. Returns a SQL string.
    """
    req = request.lower().strip()
    cols = df.columns.tolist() if df is not None else []

    # show / preview
    if any(w in req for w in ("show", "preview", "sample", "first", "top rows", "display")):
        n = 10
        m = re.search(r"(\d+)", req)
        if m:
            n = int(m.group(1))
        return f"SELECT * FROM {table} LIMIT {n};"

    # count rows
    if "how many rows" in req or "total rows" in req or "count rows" in req:
        return f"SELECT COUNT(*) AS total_rows FROM {table};"

    # describe / schema
    if any(w in req for w in ("schema", "columns", "describe", "structure", "data types")):
        return f"DESCRIBE {table};"

    # Helper: identify a metric / value column from the request
    def _detect_numeric(words):
        for w in words:
            found = _find_col(w, cols)
            if found and df is not None and pd.api.types.is_numeric_dtype(df[found]):
                return found
        # fallback: first numeric column in the DataFrame
        if df is not None:
            for c in cols:
                if pd.api.types.is_numeric_dtype(df[c]):
                    return c
        return None

    # top N by category  e.g. "top 5 region by sales"
    # Pattern variants:
    #   "top 5 region by sales"      -> group by region, order by sum(sales)
    #   "top 5 by region"            -> group by region, count
    m = re.search(r"top\s+(\d+)\s+(\w+)\s+(?:by|per)\s+(\w+)", req)
    if m:
        n, grp_raw, val_raw = int(m.group(1)), m.group(2), m.group(3)
        grp_col = _find_col(grp_raw, cols) or grp_raw
        val_col = _find_col(val_raw, cols) or _detect_numeric([val_raw])
        if val_col:
            return (
                f"SELECT {grp_col},\n"
                f"       SUM({val_col}) AS total_{val_col},\n"
                f"       COUNT(*)      AS records\n"
                f"FROM {table}\n"
                f"GROUP BY {grp_col}\n"
                f"ORDER BY total_{val_col} DESC\n"
                f"LIMIT {n};"
            )
        else:
            return (
                f"SELECT {grp_col}, COUNT(*) AS record_count\n"
                f"FROM {table}\n"
                f"GROUP BY {grp_col}\n"
                f"ORDER BY record_count DESC\n"
                f"LIMIT {n};"
            )

    m = re.search(r"top\s+(\d+).*?(?:by|per)\s+(\w+)", req)
    if m:
        n, col = int(m.group(1)), m.group(2)
        match_col = _find_col(col, cols) or col
        return (
            f"SELECT {match_col}, COUNT(*) AS record_count\n"
            f"FROM {table}\n"
            f"GROUP BY {match_col}\n"
            f"ORDER BY record_count DESC\n"
            f"LIMIT {n};"
        )

    # count by category
    m = re.search(r"(?:count|number of|distribution).*?\bby\s+(\w+)", req)
    if m:
        col = m.group(1)
        match_col = _find_col(col, cols) or col
        return (
            f"SELECT {match_col}, COUNT(*) AS count\n"
            f"FROM {table}\n"
            f"GROUP BY {match_col}\n"
            f"ORDER BY count DESC;"
        )

    # average / sum by category — value word may come BEFORE "by" or AFTER
    # e.g. "average sales by region" OR "sales by region" OR "revenue per product"
    m = re.search(r"(?:avg|average|mean|sum|total)?\s*(\w+)\s+(?:by|per)\s+(\w+)", req)
    if m:
        val_raw, grp_raw = m.group(1), m.group(2)
        val_col = _find_col(val_raw, cols) or val_raw
        grp_col = _find_col(grp_raw, cols) or grp_raw

        # if value is not numeric, try the other word or auto-pick a numeric
        if df is not None and (val_col not in df.columns or not pd.api.types.is_numeric_dtype(df[val_col])):
            maybe_num = _detect_numeric([val_raw, grp_raw])
            if maybe_num and grp_col != maybe_num:
                val_col = maybe_num

        is_avg = any(w in req for w in ("avg", "average", "mean"))
        agg_fn = "AVG" if is_avg else "SUM"
        agg_label = ("avg" if is_avg else "total") + f"_{val_col}"
        return (
            f"SELECT {grp_col},\n"
            f"       {agg_fn}({val_col}) AS {agg_label},\n"
            f"       MIN({val_col})        AS min_{val_col},\n"
            f"       MAX({val_col})        AS max_{val_col},\n"
            f"       COUNT(*)              AS records\n"
            f"FROM {table}\n"
            f"GROUP BY {grp_col}\n"
            f"ORDER BY {agg_label} DESC;"
        )

    # missing / null counts
    if any(w in req for w in ("missing", "null", "empty", "n/a values")):
        col_exprs = ",\n       ".join(
            f"SUM(CASE WHEN {c} IS NULL THEN 1 ELSE 0 END) AS {c}_nulls"
            for c in cols
        )
        return f"SELECT\n       {col_exprs}\nFROM {table};"

    # year/month trend
    if any(w in req for w in ("trend", "over time", "by month", "by year", "monthly", "yearly", "daily")):
        date_col = next((c for c in cols if "date" in c.lower() or pd.api.types.is_datetime64_any_dtype(df[c])), None) if df is not None else None
        if not date_col and cols:
            date_col = cols[0]
        num_col = next((c for c in cols if c != date_col and pd.api.types.is_numeric_dtype(df[c])), None) if df is not None else None
        agg = "COUNT(*)" if not num_col else f"SUM({num_col})"
        return (
            f"SELECT DATE_TRUNC('month', {date_col}) AS month,\n"
            f"       {agg} AS value\n"
            f"FROM {table}\n"
            f"WHERE {date_col} IS NOT NULL\n"
            f"GROUP BY month\n"
            f"ORDER BY month;"
        )

    # duplicates
    if "duplicate" in req:
        col_list = ", ".join(cols[:5]) if cols else "*"
        return (
            f"SELECT {col_list}, COUNT(*) AS copies\n"
            f"FROM {table}\n"
            f"GROUP BY {col_list}\n"
            f"HAVING COUNT(*) > 1\n"
            f"ORDER BY copies DESC;"
        )

    # unique values
    m = re.search(r"unique.*?(?:in|of|for)\s+(\w+)", req)
    if m:
        col = _find_col(m.group(1), cols) or m.group(1)
        return f"SELECT DISTINCT {col} FROM {table} ORDER BY {col};"

    # fallback: simple select
    return f"SELECT * FROM {table} LIMIT 20;\n-- I couldn't fully parse your request; please refine or write custom SQL."


def _find_col(name: str, cols: list) -> str:
    """Fuzzy-find a column name."""
    name_l = name.lower().strip()
    for c in cols:
        if c.lower() == name_l:
            return c
    for c in cols:
        if name_l in c.lower() or c.lower() in name_l:
            return c
    return ""
