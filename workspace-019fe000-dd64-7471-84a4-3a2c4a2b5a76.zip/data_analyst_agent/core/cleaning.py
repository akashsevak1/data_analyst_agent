"""
cleaning.py — Data-cleaning pipeline.
Every step logs a plain-English explanation so the user understands exactly
what was changed and why.
"""
import pandas as pd
import numpy as np
from typing import Tuple, List, Dict


def clean_data(
    df: pd.DataFrame,
    drop_duplicates: bool = True,
    fix_column_names: bool = True,
    parse_dates: bool = True,
    missing_strategy: str = "smart",
    strip_strings: bool = True,
    remove_outliers: bool = False,
    drop_high_cardinality: bool = False,
) -> Tuple[pd.DataFrame, List[Dict]]:
    """
    Return a cleaned copy of df and a step-by-step audit log.

    missing_strategy:
        'smart'   -> median for numeric, mode for categorical (default)
        'mean'    -> mean for numeric, mode for categorical
        'drop'    -> drop rows that have any missing value
        'zero'    -> 0 for numeric, 'Unknown' for categorical
        'keep'    -> leave missing values untouched
    """
    report: List[Dict] = []
    out = df.copy()

    def log(step, detail, before=None, after=None):
        entry = {"step": step, "detail": detail}
        if before is not None and after is not None:
            entry["before"] = before
            entry["after"] = after
            entry["change"] = before - after if isinstance(before, (int, float)) else None
        report.append(entry)

    # ---- 1. Column names -------------------------------------------------
    if fix_column_names:
        original_cols = list(out.columns)
        new_cols = []
        for c in original_cols:
            nc = str(c).strip().lower()
            nc = nc.replace(" ", "_").replace("-", "_")
            nc = "".join(ch for ch in nc if ch.isalnum() or ch == "_")
            new_cols.append(nc)
        out.columns = new_cols
        renamed = [
            f"{o} → {n}"
            for o, n in zip(original_cols, new_cols)
            if str(o) != n
        ]
        log(
            "Standardized column names",
            "Lower-cased names, replaced spaces/dashes with underscores, "
            "and removed special characters. This prevents bugs when "
            "referencing columns in Python or SQL."
            + (f" Renamed: {', '.join(renamed[:10])}" if renamed else " No names needed changing."),
            len(original_cols), len(new_cols),
        )

    # ---- 2. String whitespace -------------------------------------------
    if strip_strings:
        str_cols = out.select_dtypes(include="object").columns
        stripped = 0
        for c in str_cols:
            before_sample = out[c].dropna().head(5).tolist()
            out[c] = out[c].astype(str).str.strip()
            out[c] = out[c].replace({"nan": np.nan, "None": np.nan, "NaN": np.nan})
            after_sample = out[c].dropna().head(5).tolist()
            if before_sample != after_sample:
                stripped += 1
        if stripped:
            log(
                "Trimmed whitespace in text columns",
                f"Removed leading/trailing spaces from {stripped} text "
                "column(s). Hidden spaces are a common cause of duplicate "
                "categories (e.g. 'India' vs 'India ').",
            )

    # ---- 3. Duplicates ---------------------------------------------------
    if drop_duplicates:
        before = len(out)
        out = out.drop_duplicates().reset_index(drop=True)
        removed = before - len(out)
        log(
            "Removed duplicate rows",
            f"Found and deleted {removed} exact duplicate row(s). "
            "Duplicates can inflate counts and distort averages.",
            before, len(out),
        )

    # ---- 4. Date parsing -------------------------------------------------
    if parse_dates:
        converted = []
        for c in out.select_dtypes(include="object").columns:
            sample = out[c].dropna().head(50)
            if len(sample) == 0:
                continue
            try:
                parsed = pd.to_datetime(sample, errors="coerce")
                if parsed.notna().mean() > 0.85:
                    out[c] = pd.to_datetime(out[c], errors="coerce")
                    converted.append(c)
            except Exception:
                pass
        if converted:
            log(
                "Converted text columns to dates",
                f"Columns {converted} looked like dates, so they were "
                "converted to datetime. This unlocks time-series analysis "
                "(group by month, year, etc.).",
            )

    # ---- 5. Missing values -----------------------------------------------
    total_missing_before = int(out.isna().sum().sum())
    if missing_strategy == "drop":
        before = len(out)
        out = out.dropna().reset_index(drop=True)
        log(
            "Dropped rows with missing values",
            f"Removed {before - len(out)} row(s) containing at least one "
            "missing value. Use this only when missing rows are unusable.",
            before, len(out),
        )
    elif missing_strategy in ("smart", "mean", "zero"):
        for c in out.columns:
            n_miss = out[c].nunique()
            if out[c].isna().sum() == 0:
                continue
            if pd.api.types.is_numeric_dtype(out[c]):
                if missing_strategy == "zero":
                    fill = 0
                    reason = "filled with 0"
                elif missing_strategy == "mean":
                    fill = out[c].mean()
                    reason = f"filled with mean = {fill:.2f}"
                else:  # smart -> median (robust to outliers)
                    fill = out[c].median()
                    reason = f"filled with median = {fill:.2f} (median is robust to outliers)"
                out[c] = out[c].fillna(fill)
                log(f"Filled missing numeric values in '{c}'",
                    f"{out[c].isna().sum()} missing values were "
                    f"{reason}.")
            else:
                # categorical / text
                if missing_strategy == "zero":
                    fill = "Unknown"
                else:
                    mode_vals = out[c].mode()
                    fill = mode_vals.iloc[0] if len(mode_vals) > 0 else "Unknown"
                out[c] = out[c].fillna(fill)
                log(f"Filled missing text values in '{c}'",
                    f"Missing entries filled with '{fill}' (the most "
                    "frequent category, or 'Unknown' if none existed).")
    else:
        log("Kept missing values", "Strategy set to 'keep' — NaN values left as-is.")

    total_missing_after = int(out.isna().sum().sum())
    if total_missing_before > 0 or total_missing_after == 0:
        log(
            "Missing-value summary",
            f"Before cleaning: {total_missing_before:,} missing cells. "
            f"After cleaning: {total_missing_after:,} missing cells.",
            total_missing_before, total_missing_after,
        )

    # ---- 6. High-cardinality text columns -------------------------------
    if drop_high_cardinality:
        drop_cols = [
            c for c in out.select_dtypes(include="object").columns
            if out[c].nunique() > 0.7 * len(out)
        ]
        if drop_cols:
            out = out.drop(columns=drop_cols)
            log(
                "Dropped high-cardinality text columns",
                f"Removed {drop_cols} because they contain mostly unique "
                "values (likely IDs / free text) which are not useful for "
                "grouping or machine learning.",
            )

    # ---- 7. Outliers (optional) -----------------------------------------
    if remove_outliers:
        num_cols = out.select_dtypes(include=np.number).columns
        total_removed = 0
        for c in num_cols:
            q1, q3 = out[c].quantile([0.25, 0.75])
            iqr = q3 - q1
            low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            mask = (out[c] >= low) & (out[c] <= high)
            total_removed += int((~mask).sum())
            out = out[mask]
        out = out.reset_index(drop=True)
        log(
            "Removed statistical outliers",
            f"Removed {total_removed} rows whose numeric values fell "
            "outside Q1−1.5×IQR to Q3+1.5×IQR. ⚠️ Only do this if you "
            "are sure the outliers are errors, not real extremes.",
        )

    log(
        "Final shape",
        f"Cleaned dataset has {len(out):,} rows and {out.shape[1]:,} columns.",
    )
    return out, report
