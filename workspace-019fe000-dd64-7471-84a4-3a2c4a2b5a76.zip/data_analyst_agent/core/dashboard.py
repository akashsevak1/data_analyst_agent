"""
dashboard.py — Build a full interactive Plotly dashboard from any DataFrame.
The agent automatically picks columns and chart types.
"""
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List, Tuple


def _best_chart_for(df: pd.DataFrame, col: str) -> str:
    if pd.api.types.is_numeric_dtype(df[col]):
        return "histogram"
    if pd.api.types.is_datetime64_any_dtype(df[col]):
        return "timeseries"
    return "bar"


def auto_dashboard(df: pd.DataFrame) -> Tuple[List, Dict, str]:
    """
    Returns (figures, kpis, explanation).
    Each figure is a Plotly figure object; kpis is a dict of metric cards.
    """
    figures = []
    kpis = {
        "Total Rows": len(df),
        "Total Columns": df.shape[1],
        "Missing Cells": int(df.isna().sum().sum()),
        "Duplicate Rows": int(df.duplicated().sum()),
    }

    nums = df.select_dtypes(include=np.number).columns.tolist()
    cats = [c for c in df.select_dtypes(exclude=np.number).columns
            if not pd.api.types.is_datetime64_any_dtype(df[c]) and df[c].nunique() <= 25]
    dates = df.select_dtypes(include="datetime").columns.tolist()

    # KPI stats for numeric columns
    for c in nums[:3]:
        kpis[f"Avg {c}"] = round(float(df[c].mean()), 2)

    # 1. Bar chart for top categorical column
    if cats:
        c = cats[0]
        vc = df[c].value_counts().head(15).reset_index()
        vc.columns = [c, "count"]
        fig = px.bar(vc, x=c, y="count", color=c,
                     title=f"Count by {c}",
                     color_discrete_sequence=px.colors.qualitative.Set2,
                     text_auto=True)
        fig.update_layout(showlegend=False, xaxis_title=c, yaxis_title="Count")
        figures.append(("bar", c, fig))

    # 2. Histogram for first numeric column
    if nums:
        c = nums[0]
        fig = px.histogram(df, x=c, nbins=30, marginal="box",
                           title=f"Distribution of {c}",
                           color_discrete_sequence=["#3b82f6"])
        figures.append(("histogram", c, fig))

    # 3. Timeseries if date column exists
    if dates and nums:
        dcol = dates[0]
        ncol = nums[0]
        ts = df.groupby(df[dcol].dt.to_period("D"))[ncol].sum().reset_index()
        ts[dcol] = ts[dcol].dt.to_timestamp()
        ts.columns = [dcol, ncol]
        fig = px.line(ts, x=dcol, y=ncol, markers=True,
                      title=f"{ncol} over {dcol}",
                      color_discrete_sequence=["#10b981"])
        figures.append(("timeseries", f"{ncol} over {dcol}", fig))

    # 4. Correlation heatmap for numerics
    if len(nums) >= 2:
        corr = df[nums].corr(numeric_only=True)
        fig = px.imshow(corr, text_auto=".2f", color_continuous_scale="RdBu_r",
                        aspect="auto", zmin=-1, zmax=1,
                        title="Correlation Heatmap")
        figures.append(("heatmap", "correlation", fig))

    # 5. Box plot of first numeric by first categorical
    if nums and cats:
        ncol, ccol = nums[0], cats[0]
        sample = df[[ncol, ccol]].dropna()
        if sample[ccol].nunique() <= 10:
            fig = px.box(sample, x=ccol, y=ncol, color=ccol,
                         title=f"{ncol} by {ccol}",
                         color_discrete_sequence=px.colors.qualitative.Pastel)
            fig.update_layout(showlegend=False)
            figures.append(("box", f"{ncol} by {ccol}", fig))

    # 6. Scatter for two numeric columns
    if len(nums) >= 2:
        x, y = nums[0], nums[1]
        hover_data = [cats[0]] if cats else None
        color_col = cats[0] if cats else None
        fig = px.scatter(df, x=x, y=y, color=color_col, hover_data=hover_data,
                         opacity=0.7, title=f"{y} vs {x}",
                         color_discrete_sequence=px.colors.qualitative.Set1)
        figures.append(("scatter", f"{y} vs {x}", fig))

    # 7. Pie chart for second categorical
    if len(cats) >= 2:
        c = cats[1]
        vc = df[c].value_counts().head(8).reset_index()
        vc.columns = [c, "count"]
        fig = px.pie(vc, names=c, values="count", hole=0.4,
                     title=f"Proportion of {c}",
                     color_discrete_sequence=px.colors.qualitative.Bold)
        figures.append(("pie", c, fig))

    explanation = (
        "🎛️ **Auto-generated dashboard:**\n"
        f"   • {len(figures)} interactive chart(s) built automatically.\n"
        f"   • {len(kpis)} KPI metric cards (rows, columns, averages, etc.).\n"
        "   • The agent detected numeric, categorical, and date columns and\n"
        "     chose appropriate chart types for each.\n"
        "   • All Plotly charts are zoomable, hoverable, and downloadable as PNG."
    )
    return figures, kpis, explanation
