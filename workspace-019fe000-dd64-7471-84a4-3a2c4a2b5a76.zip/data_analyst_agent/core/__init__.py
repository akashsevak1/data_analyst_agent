"""
Data Analyst Agent — core modules
"""
