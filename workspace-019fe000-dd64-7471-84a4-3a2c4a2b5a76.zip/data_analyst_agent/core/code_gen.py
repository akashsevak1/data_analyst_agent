"""
code_gen.py — Generate reusable, well-commented Python analysis code for any
task. The produced code is production-ready and the agent also explains what
each block does.
"""
from typing import Dict, List


def generate_cleaning_code() -> str:
    return '''import pandas as pd
import numpy as np

# ---------- 1. Load data ----------
df = pd.read_csv("your_file.csv")   # or pd.read_excel(...)

# ---------- 2. Standardize column names ----------
df.columns = (
    df.columns.str.strip()
              .str.lower()
              .str.replace(r"[\\s-]+", "_", regex=True)
              .str.replace(r"[^a-z0-9_]", "", regex=True)
)

# ---------- 3. Remove exact duplicates ----------
df = df.drop_duplicates().reset_index(drop=True)

# ---------- 4. Trim whitespace in text columns ----------
for c in df.select_dtypes(include="object").columns:
    df[c] = df[c].astype(str).str.strip()

# ---------- 5. Auto-parse date columns ----------
for c in df.select_dtypes(include="object").columns:
    parsed = pd.to_datetime(df[c], errors="coerce")
    if parsed.notna().mean() > 0.85:
        df[c] = parsed

# ---------- 6. Fill missing values ----------
for c in df.select_dtypes(include=np.number).columns:
    df[c] = df[c].fillna(df[c].median())      # robust to outliers

for c in df.select_dtypes(exclude=np.number).columns:
    mode_val = df[c].mode().iloc[0] if not df[c].mode().empty else "Unknown"
    df[c] = df[c].fillna(mode_val)

print(df.info())
print(df.isna().sum())
'''


def generate_eda_code() -> str:
    return '''import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_theme(style="whitegrid")

df = pd.read_csv("your_file.csv")

# ---------- Quick overview ----------
print(df.shape)
print(df.head())
print(df.info())
print(df.describe())

# ---------- Missing values ----------
sns.heatmap(df.isna(), cbar=False)
plt.title("Missing-value map")
plt.show()

# ---------- Numeric distributions ----------
df.hist(bins=30, figsize=(14, 10))
plt.tight_layout()
plt.show()

# ---------- Correlation heatmap ----------
nums = df.select_dtypes(include=np.number)
plt.figure(figsize=(10, 8))
sns.heatmap(nums.corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Correlation Matrix")
plt.show()

# ---------- Pair plot (top 4 numeric columns) ----------
sns.pairplot(df.iloc[:, :5].dropna())
plt.show()
'''


def generate_sql_examples() -> Dict[str, str]:
    return {
        "Basic aggregation":
            "SELECT category, COUNT(*) AS cnt, AVG(value) AS avg_value\n"
            "FROM dataset\n"
            "GROUP BY category\n"
            "ORDER BY cnt DESC;",

        "Top-N per group (window function)":
            "WITH ranked AS (\n"
            "  SELECT *,\n"
            "         ROW_NUMBER() OVER (PARTITION BY category\n"
            "                            ORDER BY value DESC) AS rn\n"
            "  FROM dataset\n"
            ")\n"
            "SELECT * FROM ranked WHERE rn <= 5;",

        "Running total (window function)":
            "SELECT date, value,\n"
            "       SUM(value) OVER (ORDER BY date\n"
            "                        ROWS BETWEEN UNBOUNDED PRECEDING\n"
            "                                 AND CURRENT ROW) AS running_total\n"
            "FROM dataset\n"
            "ORDER BY date;",

        "Month-over-month growth":
            "WITH monthly AS (\n"
            "  SELECT DATE_TRUNC('month', date) AS m, SUM(value) AS total\n"
            "  FROM dataset GROUP BY 1\n"
            ")\n"
            "SELECT m, total,\n"
            "       LAG(total) OVER (ORDER BY m) AS prev_month,\n"
            "       ROUND((total - LAG(total) OVER (ORDER BY m)) * 100.0\n"
            "             / LAG(total) OVER (ORDER BY m), 2) AS pct_growth\n"
            "FROM monthly;",

        "Moving 7-day average":
            "SELECT date, value,\n"
            "       AVG(value) OVER (ORDER BY date\n"
            "                        ROWS BETWEEN 6 PRECEDING\n"
            "                                 AND CURRENT ROW) AS avg_7d\n"
            "FROM dataset;",

        "Duplicate detection":
            "SELECT col1, col2, COUNT(*) AS copies\n"
            "FROM dataset\n"
            "GROUP BY col1, col2\n"
            "HAVING COUNT(*) > 1;",

        "Pivot / cross-tab":
            "SELECT category,\n"
            "       SUM(CASE WHEN status='Active' THEN 1 ELSE 0 END) AS active,\n"
            "       SUM(CASE WHEN status='Inactive' THEN 1 ELSE 0 END) AS inactive\n"
            "FROM dataset\n"
            "GROUP BY category;",
    }


def explain_code_block(code: str) -> str:
    """Explain a code snippet in plain English."""
    explanations = []
    lines = code.splitlines()
    for line in lines:
        s = line.strip()
        if not s:
            continue
        if s.startswith("#"):
            continue
        if "read_csv" in s or "read_excel" in s:
            explanations.append(f"📂 `{s}` — loads your file into a pandas DataFrame.")
        elif "drop_duplicates" in s:
            explanations.append("🧹 Removes exact duplicate rows.")
        elif "fillna" in s:
            explanations.append("🧼 Fills missing values so downstream math doesn't break.")
        elif "select_dtypes" in s:
            explanations.append("🔎 Selects columns by data type (numeric, text, etc.).")
        elif "to_datetime" in s:
            explanations.append("📅 Converts text columns to proper datetime objects.")
        elif "groupby" in s:
            explanations.append("📊 Groups rows by a column (like SQL GROUP BY) for aggregation.")
        elif "sns.heatmap" in s:
            explanations.append("🎨 Draws a heatmap to visualize patterns (e.g. correlations or missing values).")
        elif "corr(" in s:
            explanations.append("🔗 Computes pairwise Pearson correlations between numeric columns.")
    return "\n".join(explanations) if explanations else "Code ready — run it cell by cell."
