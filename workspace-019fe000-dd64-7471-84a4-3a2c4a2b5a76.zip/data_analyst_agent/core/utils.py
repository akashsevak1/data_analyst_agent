"""
utils.py — Common helpers used across the agent.
Each function returns (result, explanation_in_plain_english).
"""
import pandas as pd
import numpy as np
from typing import Tuple


def load_file(path: str) -> Tuple[pd.DataFrame, str]:
    """Load CSV / Excel / Parquet / JSON into a DataFrame and explain what happened."""
    import os
    ext = os.path.splitext(path)[1].lower()

    if ext == ".csv":
        df = pd.read_csv(path)
        note = f"Read CSV file '{path}'"
    elif ext in (".xlsx", ".xls"):
        df = pd.read_excel(path)
        note = f"Read Excel file '{path}'"
    elif ext == ".parquet":
        df = pd.read_parquet(path)
        note = f"Read Parquet file '{path}'"
    elif ext == ".json":
        df = pd.read_json(path)
        note = f"Read JSON file '{path}'"
    else:
        # Try CSV as fallback
        df = pd.read_csv(path)
        note = f"Loaded '{path}' as CSV (extension unknown, tried auto-detect)"

    rows, cols = df.shape
    explanation = (
        f"✅ {note}.\n"
        f"   • Shape: {rows:,} rows × {cols:,} columns.\n"
        f"   • Columns: {', '.join(map(str, df.columns[:10]))}"
        + (f", ... (+{cols-10} more)" if cols > 10 else "")
    )
    return df, explanation


def detect_problems(df: pd.DataFrame) -> Tuple[dict, str]:
    """Scan a DataFrame for common data-quality issues and explain findings."""
    problems = {
        "missing_per_col": df.isna().sum()[df.isna().sum() > 0].to_dict(),
        "total_missing": int(df.isna().sum().sum()),
        "duplicates": int(df.duplicated().sum()),
        "dtypes": df.dtypes.astype(str).to_dict(),
        "object_cols": df.select_dtypes(include="object").columns.tolist(),
        "possible_dates": [],
        "constant_cols": [c for c in df.columns if df[c].nunique(dropna=False) <= 1],
        "high_cardinality": {
            c: int(df[c].nunique())
            for c in df.select_dtypes(include="object").columns
            if df[c].nunique() > 0.7 * len(df)
        },
        "outliers_summary": {},
    }

    # detect columns that look like dates but aren't datetime type
    for c in problems["object_cols"]:
        sample = df[c].dropna().head(20)
        if len(sample) > 0:
            try:
                parsed = pd.to_datetime(sample, errors="coerce")
                if parsed.notna().mean() > 0.8:
                    problems["possible_dates"].append(c)
            except Exception:
                pass

    # rough outlier count for numeric columns (IQR rule)
    for c in df.select_dtypes(include=np.number).columns:
        s = df[c].dropna()
        if len(s) > 10:
            q1, q3 = s.quantile([0.25, 0.75])
            iqr = q3 - q1
            low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            outliers = int(((s < low) | (s > high)).sum())
            if outliers > 0:
                problems["outliers_summary"][c] = outliers

    lines = ["🔍 Data-quality scan complete:"]
    lines.append(f"   • Missing values: {problems['total_missing']:,}")
    if problems["missing_per_col"]:
        for k, v in list(problems["missing_per_col"].items())[:8]:
            pct = v / len(df) * 100
            lines.append(f"     - {k}: {v} missing ({pct:.1f}%)")
    lines.append(f"   • Duplicate rows: {problems['duplicates']:,}")
    if problems["constant_cols"]:
        lines.append(f"   • Constant columns (no variation): {problems['constant_cols']}")
    if problems["possible_dates"]:
        lines.append(f"   • Text columns that look like dates: {problems['possible_dates']}")
    if problems["high_cardinality"]:
        lines.append(f"   • High-cardinality text columns (likely IDs): {list(problems['high_cardinality'].keys())}")
    if problems["outliers_summary"]:
        lines.append(f"   • Numeric columns with statistical outliers: {list(problems['outliers_summary'].keys())}")
    if not any([
        problems["total_missing"], problems["duplicates"],
        problems["constant_cols"], problems["possible_dates"],
        problems["high_cardinality"], problems["outliers_summary"]
    ]):
        lines.append("   ✨ No obvious problems found — data looks clean.")

    return problems, "\n".join(lines)
