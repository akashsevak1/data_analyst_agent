"""
eda.py — Automated Exploratory Data Analysis.
Produces a textual report + matplotlib/seaborn figures, and explains
every finding in plain language.
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Tuple, List, Dict
import io
import base64

sns.set_theme(style="whitegrid", palette="muted")
plt.rcParams.update({"figure.max_open_warning": 0, "figure.dpi": 100})


def _fig_to_base64(fig) -> str:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", bbox_inches="tight", dpi=100)
    plt.close(fig)
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")


def numeric_summary(df: pd.DataFrame) -> Tuple[pd.DataFrame, str]:
    """Descriptive statistics for numeric columns + plain-English summary."""
    nums = df.select_dtypes(include=np.number)
    if nums.empty:
        return pd.DataFrame(), "No numeric columns found to summarize."

    stats = nums.describe().T
    stats["missing"] = nums.isna().sum()
    stats["skew"] = nums.skew()

    lines = ["📊 **Numeric-column summary:**"]
    for c in nums.columns:
        s = nums[c].dropna()
        skew = s.skew()
        if abs(skew) > 1:
            shape = "highly skewed"
        elif abs(skew) > 0.5:
            shape = "moderately skewed"
        else:
            shape = "roughly symmetric"
        lines.append(
            f"   • **{c}**: avg {s.mean():.2f}, ranges {s.min():.2f}→{s.max():.2f}, "
            f"median {s.median():.2f}. Distribution is {shape} (skew={skew:.2f})."
        )
    return stats, "\n".join(lines)


def categorical_summary(df: pd.DataFrame) -> Tuple[Dict[str, pd.Series], str]:
    """Top categories for non-numeric columns."""
    cats = df.select_dtypes(exclude=np.number)
    if cats.empty:
        return {}, "No categorical/text columns found."

    result = {}
    lines = ["🔤 **Categorical columns:**"]
    for c in cats.columns:
        vc = df[c].value_counts(dropna=False).head(10)
        result[c] = vc
        uniq = df[c].nunique()
        lines.append(
            f"   • **{c}**: {uniq} unique values. "
            f"Top: {vc.index[0]} ({vc.iloc[0]:,} rows)."
        )
    return result, "\n".join(lines)


def correlation_matrix(df: pd.DataFrame) -> Tuple[pd.DataFrame, str]:
    """Pearson correlation for numeric columns."""
    nums = df.select_dtypes(include=np.number)
    if nums.shape[1] < 2:
        return pd.DataFrame(), "Need at least 2 numeric columns for correlation."

    corr = nums.corr(numeric_only=True)
    # find strongest pairs
    pairs = []
    cols = corr.columns.tolist()
    for i in range(len(cols)):
        for j in range(i + 1, len(cols)):
            pairs.append((cols[i], cols[j], corr.iloc[i, j]))
    pairs.sort(key=lambda x: abs(x[2]), reverse=True)

    lines = ["🔗 **Strongest correlations:**"]
    for a, b, r in pairs[:5]:
        strength = "very strong" if abs(r) > 0.8 else "strong" if abs(r) > 0.6 else "moderate" if abs(r) > 0.3 else "weak"
        direction = "positive" if r > 0 else "negative"
        lines.append(f"   • {a} ↔ {b}: r = {r:.2f} ({strength} {direction})")
    return corr, "\n".join(lines)


def generate_plots(df: pd.DataFrame, max_cats: int = 15) -> Dict[str, str]:
    """Return a dict {plot_name: base64_png}."""
    plots = {}

    nums = df.select_dtypes(include=np.number).columns.tolist()
    cats = [c for c in df.select_dtypes(exclude=np.number).columns
            if df[c].nunique() <= max_cats]

    # Histograms for numeric
    if nums:
        n = len(nums)
        ncols = 3
        nrows = (n + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 3.5 * nrows))
        axes = np.atleast_2d(axes).flatten()
        for i, c in enumerate(nums):
            sns.histplot(df[c].dropna(), ax=axes[i], kde=True, color="#3b82f6")
            axes[i].set_title(f"Distribution of {c}", fontsize=11, fontweight="bold")
        for j in range(i + 1, len(axes)):
            axes[j].set_visible(False)
        plots["distributions"] = _fig_to_base64(fig)

    # Bar charts for categorical
    if cats:
        n = len(cats)
        ncols = 2
        nrows = (n + ncols - 1) // ncols
        fig, axes = plt.subplots(nrows, ncols, figsize=(7 * ncols, 3.5 * nrows))
        axes = np.atleast_2d(axes).flatten()
        for i, c in enumerate(cats[:8]):
            vc = df[c].value_counts().head(12)
            sns.barplot(x=vc.values, y=vc.index, ax=axes[i], palette="viridis", hue=vc.index, legend=False)
            axes[i].set_title(f"Top values in {c}", fontsize=11, fontweight="bold")
        for j in range(i + 1, len(axes)):
            axes[j].set_visible(False)
        plots["categorical_bars"] = _fig_to_base64(fig)

    # Correlation heatmap
    if len(nums) >= 2:
        corr = df[nums].corr(numeric_only=True)
        fig, ax = plt.subplots(figsize=(1.1 * len(nums) + 3, 0.9 * len(nums) + 2))
        sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0,
                    ax=ax, square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
        ax.set_title("Correlation Heatmap", fontsize=13, fontweight="bold")
        plots["correlation_heatmap"] = _fig_to_base64(fig)

    # Box plots (numeric)
    if nums:
        n = min(len(nums), 6)
        fig, axes = plt.subplots(1, n, figsize=(4 * n, 4))
        if n == 1:
            axes = [axes]
        for i, c in enumerate(nums[:n]):
            sns.boxplot(y=df[c], ax=axes[i], color="#f59e0b")
            axes[i].set_title(f"Box plot: {c}", fontsize=11, fontweight="bold")
        plots["boxplots"] = _fig_to_base64(fig)

    # Scatter matrix (first 4 numeric)
    if len(nums) >= 2:
        sample = df[nums[:4]].dropna().head(2000)
        if len(sample) > 5:
            fig = plt.figure(figsize=(10, 8))
            pd.plotting.scatter_matrix(sample, ax=fig.add_subplot(111),
                                       diagonal="kde", alpha=0.5, color="#3b82f6")
            fig.suptitle("Scatter Matrix (top 4 numeric columns)",
                         fontsize=13, fontweight="bold", y=1.02)
            plots["scatter_matrix"] = _fig_to_base64(fig)

    return plots


def run_eda(df: pd.DataFrame) -> Tuple[Dict, str]:
    """Run full EDA and return (results_dict, full_explanation)."""
    results = {}

    num_stats, num_text = numeric_summary(df)
    cat_stats, cat_text = categorical_summary(df)
    corr, corr_text = correlation_matrix(df)

    results["numeric_stats"] = num_stats
    results["categorical_stats"] = cat_stats
    results["correlation"] = corr
    results["plots"] = generate_plots(df)

    full = f"{num_text}\n\n{cat_text}\n\n{corr_text}"
    full += (
        "\n\n📈 **Charts generated:**\n"
        "   • Distributions (histograms + KDE curves)\n"
        "   • Categorical bar charts\n"
        "   • Correlation heatmap\n"
        "   • Box plots for outlier detection\n"
        "   • Scatter matrix for numeric relationships\n"
    )
    return results, full
